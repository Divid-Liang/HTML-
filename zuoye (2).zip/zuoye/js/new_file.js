document.addEventListener('DOMContentLoaded', function() {
var smiley=document.getElementById("smiley");
//初始定位居中
var posX=50;
var posY=50;
//定义笑脸位置更新
function updatedPosition(){
	smiley.style.left=posX+'%';
	smiley.style.top=posY+'%';
}
//键盘监听
document.addEventListener('keydown', function(e) {
	var key = e.key.toLowerCase();
	var moved=false;
	if(key=='w'){
		posY=Math.max(5,posY-5);
		moved=true;
	}
	else if (key === 's') {
    posY = Math.min(95, posY + 5);
    moved = true;
	}
    else if (key === 'a') {
    posX = Math.max(5, posX - 5);
    moved = true;
    }
    else if (key === 'd') {
    posX = Math.min(95, posX + 5);
    moved = true;
    }
    if (moved){
    	updatedPosition();
    	e.preventDefault();
    }
   });
   updatedPosition();
  });
